﻿using BusinessObjects.Dtos.Meals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects.Dtos.Orders
{
   public class OrderDto:BaseEntity
    {
        public int OrderNum { get; set; }

        public DateTime OrderDate { get; set; }

        public decimal Total { get; set; }

        public int MealsCount { get; set; }

        public List<MealsDto> Meals { get; set; }
    }
}
