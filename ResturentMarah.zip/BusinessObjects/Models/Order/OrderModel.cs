﻿using BusinessObjects.Models.Meals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects.Models.Order
{
    public class OrderModel
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public int OrderNum { get; set; }

        public DateTime OrderDate { get; set; }

        public decimal Total { get; set; }

        public int MealsCount { get; set; }

        public List<MealsModel> Meals { get; set; }
    }
}
