﻿using BusinessLogic;
using BusinessObjects.Dtos.Meals;
using BusinessObjects.Dtos.Orders;
using BusinessObjects.Models.Order;
using Microsoft.AspNetCore.Mvc;

namespace ResturentMarah.Controllers
{

    [ApiController]
    [Route("api/[Controller]/[Action]")]
    public class OrderController : ControllerBase
    {
        private readonly OrderBl _ordersBL=new();
        private readonly MealsBl _mealsBL = new();
        [HttpPost]
        public ActionResult Create(CreateOrderDto inputFromUsers)
        {
            
            var meals = _mealsBL.GetAll().Where(m => inputFromUsers.Meals.Contains(m.Id)).ToList();

            // Ensure that all meals are found
            if (meals.Count != inputFromUsers.Meals.Count)
            {
                return Ok(new { message = "Some of the meals provided do not exist." });
            }

            // Create the OrdersModel
            var newOrder = new OrderModel
            {
                Meals = meals,
                OrderDate = DateTime.Now // Set the current date as the order date
            };

            // Use OrdersBL to handle the creation of the order
            var createdOrder = _ordersBL.Create(newOrder);

            // Return the created order as a response
            return Ok(createdOrder);
        }

        [HttpGet]
        public ActionResult Get()
        {
            var result = _ordersBL.GetAll();

            
            var modelToDto = result.Select(x => new OrderDto()
            {
                Id = x.Id,
                OrderNum = x.OrderNum,
                OrderDate = x.OrderDate,
                Total = x.Total,
                MealsCount = x.MealsCount,
                Meals = x.Meals.Select(meal => new MealsDto
                {
                    Id = meal.Id,
                    Name = meal.Name,
                    Description = meal.Description,
                    Weight = meal.Weight,
                    Price = meal.Price,
                    Calories = meal.Calories,
                    Code = meal.Code
                }).ToList()
            }).ToList();

            return Ok(modelToDto);
        }

        [HttpGet]
        public ActionResult GetById(Guid idFromUsers)
        {
            var result = _ordersBL.GetById(idFromUsers);

            if (result == null)
            {
                return Ok(new { message = "Order not found" });
            }

            // Convert OrdersModel to OrdersDto and map the Meals correctly
            var modelToDto = new OrderDto()
            {
                Id = result.Id,
                OrderNum = result.OrderNum,
                OrderDate = result.OrderDate,
                Total = result.Total,
                MealsCount = result.MealsCount,
                Meals = result.Meals.Select(meal => new MealsDto
                {
                    Id = meal.Id,
                    Name = meal.Name,
                    Description = meal.Description,
                    Weight = meal.Weight,
                    Price = meal.Price,
                    Calories = meal.Calories,
                    Code = meal.Code
                }).ToList()
            };

            return Ok(modelToDto);
        }

        [HttpDelete]
        public ActionResult Delete(Guid id)
        {
            var success = _ordersBL.Delete(id);

            if (!success)
            {
                return Ok(new { message = "Order not found or already deleted" });
            }

            return Ok(new { message = "Order deleted successfully" });
        }

    }
}
