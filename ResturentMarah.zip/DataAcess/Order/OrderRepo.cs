﻿using BusinessObjects.Models.Meals;
using BusinessObjects.Models.Order;
using DataAcess.Meals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcess.Order
{
    public class OrderRepo
    {

        private readonly static List<OrderEntity> _orders = new();

        public OrderModel Create(OrderModel inputFromUser)
        {

            var mealsEntities = inputFromUser.Meals.Select(meal => new MealsEntity
            {
                Id = meal.Id,
                Name = meal.Name,
                Code = meal.Code,
                Price = meal.Price,
                Weight = meal.Weight,
                Calories = meal.Calories,
                Description = meal.Description
            }).ToList();


            var total = inputFromUser.Meals.Sum(meal => meal.Price);
            var mealsCount = inputFromUser.Meals.Count;


            var modelToEntity = new OrderEntity()
            {
                Id = inputFromUser.Id,
                Meals = mealsEntities,
                OrderNum = inputFromUser.OrderNum,
                OrderDate = inputFromUser.OrderDate,
            };


            _orders.Add(modelToEntity);


            return new OrderModel
            {
                Id = inputFromUser.Id,
                OrderNum = inputFromUser.OrderNum,
                OrderDate = inputFromUser.OrderDate,
                Total = total,
                MealsCount = mealsCount,
                Meals = inputFromUser.Meals
            };
        }



        public List<OrderModel> GetAll()
        {

            var result = _orders.Where(a => a.IsDeleted != true).Select(order => new OrderModel()
            {
                Id = order.Id,
                OrderNum = order.OrderNum,
                OrderDate = order.OrderDate,
                MealsCount = order.Meals.Count,
                Meals = order.Meals.Select(meal => new MealsModel()
                {
                    Id = meal.Id,
                    Name = meal.Name,
                    Code = meal.Code,
                    Price = meal.Price,
                    Weight = meal.Weight,
                    Calories = meal.Calories,
                    Description = meal.Description
                }).ToList(),
                Total = order.Meals.Sum(meal => meal.Price),
            }).ToList();

            return result;
        }

        public bool Delete(Guid inputId)
        {

            var order = _orders.FirstOrDefault(o => o.Id == inputId);
            if (order != null && order.IsDeleted != true)
            {

                order.SetIsDeleted();

                return true;
            }

            return false;
        }

    }
}
