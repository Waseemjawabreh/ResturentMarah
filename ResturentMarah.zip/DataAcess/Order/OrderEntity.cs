﻿using DataAcess.Meals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcess.Order
{
    public class OrderEntity : BaseEntity
    {
        public int OrderNum { get; set; }

        public DateTime OrderDate { get; set; }

        public ICollection<MealsEntity> Meals { get; set; }
    }
}
