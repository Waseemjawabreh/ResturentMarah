﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcess.Meals
{
    public class MealsEntity:BaseEntity
    {

        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;

        public string Weight { get; set; } = string.Empty;

        public decimal Price { get; set; }

        public decimal Calories { get; set; }

        public int Code { get; set; }
    }
}
