﻿using BusinessObjects.Models.Order;
using DataAcess.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class OrderBl
    {

        private readonly OrderRepo _ordersRepo=new();
        public OrderModel Create(OrderModel inputFromUsers)
        {
            var result = _ordersRepo.Create(inputFromUsers);
            return result;
        }

        public List<OrderModel> GetAll()
        {
            var result = _ordersRepo.GetAll();
            return result;

        }

        public OrderModel GetById(Guid idFromUser)
        {
            var allOrders = _ordersRepo.GetAll();
            var result = allOrders.FirstOrDefault(m => m.Id == idFromUser);

            return result;
        }


        public bool Delete(Guid idFromUser)
        {
            var result = _ordersRepo.Delete(idFromUser);
            return result;
        }
    }
}
