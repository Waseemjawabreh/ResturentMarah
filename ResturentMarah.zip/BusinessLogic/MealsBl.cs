﻿using BusinessObjects.Models.Meals;
using DataAcess.Meals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class MealsBl
    {
        private readonly MealsRepo _mealsRepo=new();


        public MealsModel Create(MealsModel inputFromUser)
        {
            var result = _mealsRepo.Create(inputFromUser);
            return result;
        }

        public List<MealsModel> GetAll()
        {
            var result = _mealsRepo.GetAll();
            return result;
        }

        public MealsModel GetById(Guid idFromUser)
        {
            var allMeals = _mealsRepo.GetAll();
            var result = allMeals.FirstOrDefault(m => m.Id == idFromUser);

            return result;
        }
        public MealsModel Edit(MealsModel inputFromUser)
        {
            var result = _mealsRepo.Edit(inputFromUser);
            return result;
        }
        public bool Delete(Guid idFromUser)
        {
            var result = _mealsRepo.Delete(idFromUser);
            return result;
        }
      
    }
}

